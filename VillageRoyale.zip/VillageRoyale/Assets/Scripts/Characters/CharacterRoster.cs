using UnityEngine;
[CreateAssetMenu(menuName = "Royale/Roster")]
public class CharacterRoster : ScriptableObject {
    [System.Serializable] public class Character { public string id; public string outfitStyle; public GameObject prefab; } // cosmetic only
    public Character[] characters = new Character[GameConfig.CharacterCount];
    // Stats are NOT per character: all use GameConfig (200 HP, 10 dmg).
}
