using UnityEngine; using UnityEngine.AI;
[RequireComponent(typeof(NavMeshAgent), typeof(Health))]
public class ZombieAI : MonoBehaviour {
    enum S { Idle, Patrol, Chase, Attack, Dead }
    public float detectRange = 25, attackRange = 1.8f, attackCooldown = 1.2f; public int attackDamage = 10;
    S state = S.Idle; NavMeshAgent agent; Transform player; float nextAtk;
    public System.Action<ZombieAI> OnDeath;
    void Awake() { agent = GetComponent<NavMeshAgent>(); var h = GetComponent<Health>(); h.instantKill = true; h.Died += Die; }
    void Start() { var p = GameObject.FindGameObjectWithTag("Player"); if (p) player = p.transform; state = S.Patrol; }
    void Update() {
        if (state == S.Dead || !player) return;
        float d = Vector3.Distance(transform.position, player.position);
        if (d <= attackRange) { state = S.Attack; agent.ResetPath(); if (Time.time >= nextAtk) { nextAtk = Time.time + attackCooldown; player.GetComponent<Health>()?.TakeDamage(attackDamage); } }
        else if (d <= detectRange) { state = S.Chase; agent.SetDestination(player.position); }
        else if (!agent.hasPath || agent.remainingDistance < 1f) { state = S.Patrol; agent.SetDestination(transform.position + Random.insideUnitSphere * 10f); }
    }
    void Die() { state = S.Dead; agent.enabled = false; OnDeath?.Invoke(this); Destroy(gameObject, 2f); }
}
