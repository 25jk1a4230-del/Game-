using UnityEngine; using System.Collections;
public class ZombieSpawner : MonoBehaviour {
    public ZombieAI prefab; public Transform[] points; public int maxAlive = 12; public float respawnDelay = 3f; int alive;
    void Start() { for (int i = 0; i < maxAlive; i++) Spawn(); }
    void Spawn() { var z = Instantiate(prefab, points[Random.Range(0, points.Length)].position, Quaternion.identity); alive++; z.OnDeath += _ => { alive--; StartCoroutine(Respawn()); }; }
    IEnumerator Respawn() { yield return new WaitForSeconds(respawnDelay); if (alive < maxAlive) Spawn(); }
}
