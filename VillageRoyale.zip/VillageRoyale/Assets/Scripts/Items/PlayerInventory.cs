using UnityEngine;
public class PlayerInventory : MonoBehaviour {
    public Health health; public Weapon primary, secondary, melee; public int medikits;
    public bool Healing { get; private set; } public float HealProgress;
    Vector3 lastPos;
    public void PickupMedikit() => medikits++;
    public void UseMedikit() { if (medikits > 0 && !Healing && health.current < GameConfig.MaxHP) { Healing = true; HealProgress = 0; lastPos = transform.position; health.Damaged += CancelOnHit; } }
    void CancelOnHit(int _) => CancelHeal();
    public void CancelHeal() { Healing = false; health.Damaged -= CancelOnHit; }
    void Update() {
        if (!Healing) return;
        if ((transform.position - lastPos).sqrMagnitude > 0.01f || Input.GetButton("Fire1")) { CancelHeal(); return; }
        HealProgress += Time.deltaTime / GameConfig.HealTime;
        if (HealProgress >= 1f) { medikits--; health.Heal(GameConfig.MedikitHeal); CancelHeal(); }
    }
}
