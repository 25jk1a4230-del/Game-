using System;
using UnityEngine;
public class Health : MonoBehaviour {
    public int current = GameConfig.MaxHP;
    public bool instantKill;      // true for training zombies
    public bool canBeKnocked;     // Duo/Squad
    public bool IsKnocked { get; private set; }
    public bool IsDead { get; private set; }
    public event Action<int> Damaged; public event Action Knocked, Died;
    public void TakeDamage(int amount) {
        if (IsDead) return;
        current = instantKill ? 0 : Mathf.Max(0, current - amount);
        Damaged?.Invoke(amount);
        if (current > 0) return;
        if (canBeKnocked && !IsKnocked) { IsKnocked = true; Knocked?.Invoke(); }
        else { IsDead = true; Died?.Invoke(); }
    }
    public void Heal(int amount) { if (!IsDead) current = Mathf.Min(GameConfig.MaxHP, current + amount); }
    public void Revive() { IsKnocked = false; current = GameConfig.MaxHP / 4; }
}
