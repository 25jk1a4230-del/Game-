using UnityEngine;
// Damage is intentionally NOT a field: every hit is GameConfig.BulletDamage.
[CreateAssetMenu(menuName = "Royale/Weapon")]
public class WeaponData : ScriptableObject {
    public string weaponName; public bool isMelee;
    public float fireRate = 8f;     // shots/sec
    public int magazine = 30;
    public float reloadTime = 2f;
    public float range = 80f;
    public float spreadDeg = 2f, aimSpreadDeg = 0.5f;
    public int pellets = 1;         // shotgun > 1
    public Vector2 recoil = new Vector2(0.2f, 0.5f);
}
