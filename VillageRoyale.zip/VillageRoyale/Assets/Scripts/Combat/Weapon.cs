using UnityEngine;
public class Weapon : MonoBehaviour {
    public WeaponData data; public LayerMask hitMask = ~0;
    public int ammoInMag { get; private set; } public bool Reloading { get; private set; }
    float nextShot, reloadEnd;
    void Start() { ammoInMag = data.magazine; }
    void Update() { if (Reloading && Time.time >= reloadEnd) { ammoInMag = data.magazine; Reloading = false; } } // unlimited reserve
    public void Reload() { if (!Reloading && ammoInMag < data.magazine) { Reloading = true; reloadEnd = Time.time + data.reloadTime; } }
    public bool TryFire(Transform aim, bool aiming, Health owner) {
        if (Reloading || Time.time < nextShot) return false;
        if (ammoInMag <= 0) { Reload(); return false; }
        nextShot = Time.time + 1f / data.fireRate; ammoInMag--;
        float spread = aiming ? data.aimSpreadDeg : data.spreadDeg;
        for (int i = 0; i < Mathf.Max(1, data.pellets); i++) {
            Vector3 dir = Quaternion.Euler(Random.Range(-spread, spread), Random.Range(-spread, spread), 0) * aim.forward;
            if (Physics.Raycast(aim.position, dir, out var hit, data.range, hitMask)) {
                var h = hit.collider.GetComponentInParent<Health>();
                if (h != null && h != owner) h.TakeDamage(GameConfig.BulletDamage);
            }
        }
        return true;
    }
}
