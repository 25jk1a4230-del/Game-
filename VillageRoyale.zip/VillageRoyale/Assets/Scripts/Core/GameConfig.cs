public static class GameConfig {
    public const int MaxHP = 200;
    public const int BulletDamage = 10;   // fixed for every weapon, no multipliers
    public const int MedikitHeal = 50;
    public const float HealTime = 3f;
    public const int CharacterCount = 15;
}
public enum GameMode { Solo, Duo, Squad, Training }
