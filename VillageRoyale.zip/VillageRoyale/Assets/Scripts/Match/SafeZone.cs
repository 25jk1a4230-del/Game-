using UnityEngine;
public class SafeZone : MonoBehaviour {
    [System.Serializable] public struct Phase { public float waitTime, shrinkTime, endRadius, dps; }
    public Phase[] phases; public float startRadius = 600; public Vector2 center;
    public float Radius { get; private set; } public int PhaseIndex { get; private set; } float t, from; bool shrinking;
    void Start() { Radius = from = startRadius; }
    void Update() {
        if (PhaseIndex >= phases.Length) return;
        var p = phases[PhaseIndex]; t += Time.deltaTime;
        if (!shrinking && t >= p.waitTime) { shrinking = true; t = 0; from = Radius; }
        else if (shrinking) { Radius = Mathf.Lerp(from, p.endRadius, t / p.shrinkTime); if (t >= p.shrinkTime) { shrinking = false; t = 0; PhaseIndex++; } }
    }
    public bool IsInside(Vector3 pos) => Vector2.Distance(new Vector2(pos.x, pos.z), center) <= Radius;
    public float DamagePerSecond => PhaseIndex < phases.Length ? phases[PhaseIndex].dps : phases[phases.Length - 1].dps;
}
