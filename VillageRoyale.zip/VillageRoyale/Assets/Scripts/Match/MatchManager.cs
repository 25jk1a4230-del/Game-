using UnityEngine; using System.Collections.Generic;
public class MatchManager : MonoBehaviour {
    public GameMode mode; public List<Health> combatants = new List<Health>();
    public int teamSize => mode == GameMode.Duo ? 2 : mode == GameMode.Squad ? 4 : 1;
    public System.Action<bool> OnMatchEnd; int alive;
    void Start() {
        alive = combatants.Count;
        foreach (var h in combatants) { h.canBeKnocked = teamSize > 1; var c = h; h.Died += () => { alive--; if (c.CompareTag("Player")) OnMatchEnd?.Invoke(false); else if (alive <= 1) OnMatchEnd?.Invoke(true); }; }
    }
    public int Rank => alive + 1;  // TODO: team-based win check for Duo/Squad
}
