using UnityEngine;
// Put on any player/AI. Applies zone damage in whole-HP ticks each second.
public class ZoneDamage : MonoBehaviour {
    public SafeZone zone; public Health health; float tick;
    void Update() { if (zone.IsInside(transform.position)) return; tick += Time.deltaTime; if (tick >= 1f) { tick = 0; health.TakeDamage(Mathf.RoundToInt(zone.DamagePerSecond)); } }
}
